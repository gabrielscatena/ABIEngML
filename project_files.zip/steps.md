0. After the creation of files and directories, write all tests to be done. 
1. Create a virtual environment and activate it.
2. Start to write the app.py file using the tests as base to define the structure.
3. Make every HTML file content.
4. Make the static CSS file content. 
5. Starting testing with all RED. One by one, make it GREEN and without Warnings.
6. if all GREEN, run pip freeze > requirements.txt
7. Iterate over the code to make it better and fulfill the requirements.

99. Use AI to correct grammar errors and 'typos'.

