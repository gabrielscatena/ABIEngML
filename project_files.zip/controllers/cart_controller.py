# controllers/cart_controller.py

from flask import Blueprint, render_template, flash, redirect, url_for
from sqlalchemy.orm import Session, joinedload
from models import CartItem, Product
from flask_jwt_extended import jwt_required

cart_bp = Blueprint('cart', __name__)
auth_strategy = None  # Will be set in app.py

@cart_bp.route('/cart')
@jwt_required()
def view_cart():
    user = auth_strategy.get_current_user()
    db: Session = cart_bp.app.SessionLocal()
    cart_items = db.query(CartItem).options(joinedload(CartItem.product)).filter_by(user_id=user.id).all()
    db.close()
    return render_template('cart.html', cart_items=cart_items)

@cart_bp.route('/cart/add/<int:product_id>')
@jwt_required()
def add_to_cart(product_id):
    user = auth_strategy.get_current_user()
    db: Session = cart_bp.app.SessionLocal()
    product = db.get(Product, product_id)
    if not product:
        db.close()
        flash('Product not found.')
        return redirect(url_for('product.index'))
    existing_item = db.query(CartItem).filter_by(user_id=user.id, product_id=product_id).first()
    if existing_item:
        existing_item.quantity += 1
    else:
        new_cart_item = CartItem(user_id=user.id, product_id=product_id, quantity=1)
        db.add(new_cart_item)
    db.commit()
    db.close()
    flash('Product added to cart.')
    return redirect(url_for('cart.view_cart'))

@cart_bp.route('/cart/remove/<int:item_id>')
@jwt_required()
def remove_from_cart(item_id):
    user = auth_strategy.get_current_user()
    db: Session = cart_bp.app.SessionLocal()
    cart_item = db.get(CartItem, item_id)
    if cart_item and cart_item.user_id == user.id:
        db.delete(cart_item)
        db.commit()
        flash('Item removed from cart.')
    else:
        flash('Item not found in your cart.')
    db.close()
    return redirect(url_for('cart.view_cart'))
